<!DOCTYPE HTML>

   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <?php
	
    $fname= $_POST['fname'];
	$lname= $_POST['lname'];
	$email= $_POST['email'];
	$contact= $_POST['contact'];
	$age= $_POST['age'];
	$sex =$_POST['sex'];
	$cp =$_POST['cp'];
	$trestbps =$_POST['trestbps'];
	$chol =$_POST['chol'];
	$fbs =$_POST['fbs'];
	$restecg =$_POST['restecg'];
	$thalach =$_POST['thalach'];
	$exang =$_POST['exang'];
	$oldpeak =$_POST['oldpeak'];
	$slope =$_POST['slope'];
	$ca =$_POST['ca'];
	$thal =$_POST['thal'];
	//$output = system("python ayu.py $age $sex $cp $trestbps $chol $fbs $restecg $thalach $exang $oldpeak $slope $ca $thal");
	//echo $output;
	$fp = fopen('data.txt', 'w');
	fwrite($fp, "$age $sex $cp $trestbps $chol $fbs $restecg $thalach $exang $oldpeak $slope $ca $thal");
	fclose($fp);
	sleep(5);
	$f = fopen("result.txt","r");
	$output= fgets($f);
	fclose($f);	

	//49 1 4 145 222 0 0 122 0 2 2 -9 -9
	if(!empty($fname) || !empty($lname) ||!empty($email) ||!empty($contact) ||!empty($message)){
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbname = "tickernel";
	//create connection
	$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
	if (mysqli_connect_error()) {
	 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
	} else {
	 $sl= "INSERT INTO appointment(firstname,lastname,email,contact) values('$fname','$lname','$email','$contact')";
	 $sl2= "INSERT INTO predictor(AGE,SEX,CP,RESTBP,CHOL,FBS,RESTECG,THALACH,EXANG,OLDPEAK,SLOPE,CA,THAL,Output) values('$age','$sex','$cp','$trestbps','$chol','$fbs','$restecg','$thalach','$exang','$oldpeak','$slope','$ca','$thal','$output')";
	 if ($conn->query($sl) && $conn->query($sl2)){
	  //echo "New record inserted sucessfully";
	 }
	 $conn->close();
	}
	}
	else{
	echo "All fields required !";
	die();
	}
	
    $No=0;
    $l=0;
    $m=0;
    $H=0;
    $Ext_H=0;

         if($output==0)
               $No=1;
         else if($output==1)
               $l=1;
          else if($output==2)
               $m=1;
           else if($output==3)           
               $H=1;
         else
               $Ext_H =1; 
     function getval($val)
     {
     	if($val==1)
     	{return '#FF0000';}
     }     
  ?>
    

   <body background="blog-4.jpg">

   	<div class="container" style="margin-top: 10%">
   		
   		<div class="row">
   		<div class="col-md-5" style="width:200px;height:100px;border:1px solid #000; background-color: <?=getval($No) ?>;">NO RISK!</div>
   		<div class="col-md-2"></div>
   		<div class="col-md-5" style="width:200px;height:100px;border:1px solid #000; background-color: <?=getval($l) ?>;">LOW RISK!</div>
   	   </div>

   	  <br>
   	  <br>

   		<div class="row">
   		<div class="col-md-5" style="width:200px;height:100px;border:1px solid #000; background-color: <?=getval($m) ?>;">MEDIUM RISK!</div>
   		<div class="col-md-2"></div>
   		<div class="col-md-5" style="width:200px;height:100px;border:1px solid #000; background-color: <?=getval($H) ?>;">HIGH RISK!</div>
   	    </div>
  
      <br>
   	  <br>
   

        <div class="row">
        	<div class="col-md-3"></div>
     <div class="col-md-5" style="width:200px;height:100px;border:1px solid #000; background-color: <?=getval($Ext_H) ?>;">EXTREMLY HIGH RISK !</div>
     </div>



   	</div>
<div class="contain">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
<div class="square">
<div class="square black">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
    
	</body>
</html>

