import os.path
import time
from keras.models import load_model
import numpy as np
import pandas as pd
def check():
    file_path="C:\\xampp\\htdocs\\TICKERNEL\\data.txt"
    while not os.path.exists(file_path):
        time.sleep(5)
    if os.path.isfile(file_path):
        model = load_model('model.h5')
        filename = "data.txt"
        file = open(filename, "r")   
        s=file.readline()
        file.close()
        x=s.split()
        arr={}
        for i in range(len(x)):
            if(i==9):
                arr[i]=float(x[i])
            else:
                arr[i]=int(x[i],10)
        b={}
        for i in range(len(arr)):
            b[i]=arr[i]
        df = pd.DataFrame(b , columns =[0,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],index=[0]) 
        test=model.predict(df)
        result = np.where(test == np.amax(test))[1][0]
        f=open("result.txt",'w')
        f.write(str(result))
        f.close()
        
        #delete file data.txt
        os.remove("data.txt")
        check()
    
    else:
        raise ValueError("%s isn't a file!" % file_path)
check()