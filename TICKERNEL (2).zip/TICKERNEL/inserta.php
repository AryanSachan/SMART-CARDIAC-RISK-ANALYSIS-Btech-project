<?php
session_start();
$fname= $_POST['fname'];
$lname= $_POST['lname'];
$email= $_POST['email'];
$contact= $_POST['contact'];
$age= $_POST['age'];
$sex =$_POST['sex'];
$cp =$_POST['cp'];
$trestbps =$_POST['trestbps'];
$chol =$_POST['chol'];
$fbs =$_POST['fbs'];
$restecg =$_POST['restecg'];
$thalach =$_POST['thalach'];
$exang =$_POST['exang'];
$oldpeak =$_POST['oldpeak'];
$slope =$_POST['slope'];
$ca =$_POST['ca'];
$thal =$_POST['thal'];
//$output = system("python ayu.py $age $sex $cp $trestbps $chol $fbs $restecg $thalach $exang $oldpeak $slope $ca $thal");
//echo $output;
/*
$fp = fopen('data.txt', 'w');
fwrite($fp, "$age $sex $cp $trestbps $chol $fbs $restecg $thalach $exang $oldpeak $slope $ca $thal");
fclose($fp);



//49 1 4 145 222 0 0 122 0 2 2 -9 -9
if(!empty($fname) || !empty($lname) ||!empty($email) ||!empty($contact) ||!empty($message)){
	$host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "tickernel";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $sl= "INSERT INTO appointment(firstname,lastname,email,contact) values('$fname','$lname','$email','$contact')";
	 $sl2= "INSERT INTO predictor(AGE,SEX,CP,RESTBP,CHOL,FBS,RESTECG,THALACH,EXANG,OLDPEAK,SLOPE,CA,THAL) values('$age','$sex','$cp','$trestbps','$chol','$fbs','$restecg','$thalach','$exang','$oldpeak','$slope','$ca','$thal')";
	 if ($conn->query($sl) && $conn->query($sl2)){
      //echo "New record inserted sucessfully";
	 }
     $conn->close();
    }
}
else{
	echo "All fields required !";
	die();
}
sleep(5);*/
//$f=fopen('result.txt','r');
//$res=$f.readline();
//fclose($f);
//echo readfile("result.txt");
$f = fopen("result.txt","r");
$_SESSION['value']= fgets($f);
fclose($f);
?>